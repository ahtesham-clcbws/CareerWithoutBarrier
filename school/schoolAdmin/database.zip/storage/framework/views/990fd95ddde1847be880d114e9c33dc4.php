<!-- resources/views/home.blade.php -->


<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'Benefit'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb text-right">
        <li><a href="<?php echo e(route('course.category')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('course.category')); ?>">Benefit</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default m-t-15">
                <div class="panel-heading">Add Benefit List</div>
                <div class="panel-body">
                    <div class="card alert">
                        <div class="card-body">
                            <form action="<?php echo e(route('home.savebenefits')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <p>Benefit</p>
                                    <input type="text" name="benefit" id="" required class="form-control input-focus">
                                </div>

                                <input type="submit" class="btn btn-warning btn-flat m-b-10 m-l-5" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <h4>Govt Website List</h4>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Text</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $benefit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td>
                                    <p><?php echo e($benefits->benefits); ?></p>
                                </td>

                                <td style="text-align: center">
                                    <a href="<?php echo e(route('home.deletebenefits', ['id' => $benefits->id])); ?>">
                                        <span class="fa fa-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/Home/benefit.blade.php ENDPATH**/ ?>