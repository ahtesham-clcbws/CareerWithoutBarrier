<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'Sub Category'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb text-right">
    <li><a href="<?php echo e(route('course.category')); ?>">Classes</a></li>
    <li><a href="<?php echo e(route('course.subcategory')); ?>"> Sub Category</a></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h4>Sub Category List</h4>
        <hr>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoriess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($subcategoriess->subcategory_name); ?></td>
                        <td style="text-align:center">
                            <span class="badge badge-<?php echo e($subcategoriess->status ? 'primary' : 'dark'); ?>">
                                <?php echo e($subcategoriess->status ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/courses/subcategoryall.blade.php ENDPATH**/ ?>