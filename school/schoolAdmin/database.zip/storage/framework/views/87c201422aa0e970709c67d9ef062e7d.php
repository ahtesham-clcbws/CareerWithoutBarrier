<!-- resources/views/home.blade.php -->


<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', $category->name ? $category->name : 'Add Sub Category'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb text-right">
        <li><a href="<?php echo e(route('course.category')); ?>">Classes</a></li>
        <li><a href="<?php echo e(route('course.category')); ?>"><?php echo e($category->name); ?></a></li>

    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default m-t-15">
                <div class="panel-heading">Add SubCategory</div>
                <div class="panel-body">
                    <div class="card alert">
                        <div class="card-body">
                            <form action="<?php echo e(route('course.savesubcategory')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>"
                                    class="form-control input-focus" placeholder="Add Category">
                                <div class="form-group">
                                    <p class="text-muted m-b-15 f-s-12">Add New Sub Category/Section.</p>
                                    <input type="text" name="subcategory" class="form-control input-focus"
                                        placeholder="Add Category">
                                </div>

                                <div class="form-group">
                                    <input type="file" id="fileInput" class="form-control input-focus" name="image">
                                    <img id="imagePreview" src="#" alt="Image Preview"
                                        style="display: none;width:200px">

                                </div>
                                <input type="submit" class="btn btn-warning btn-flat m-b-10 m-l-5" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <h4>Category List</h4>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($subCategories->subcategory_name); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e($subCategories->status ? 'primary' : 'dark'); ?>">
                                        <?php echo e($subCategories->status ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('fileInput');
        const imagePreview = document.getElementById('imagePreview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                imagePreview.src = '#';
                imagePreview.style.display = 'none';
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/courses/subcategory_by_id.blade.php ENDPATH**/ ?>