<p>Your OTP is: <?php echo e($otp); ?></p>
<?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/emails/otp.blade.php ENDPATH**/ ?>