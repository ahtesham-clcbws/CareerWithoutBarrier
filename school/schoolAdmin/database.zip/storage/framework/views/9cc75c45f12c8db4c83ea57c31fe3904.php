<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'Course List'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb text-right">
    <li><a href="<?php echo e(route('course.category')); ?>">Classes</a></li>
    <li><a href="<?php echo e(route('course.subcategory')); ?>"> Courses</a></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card alert">
            <div class="card-header">
                <h4>Course List </h4>
                <div class="card-header-right-icon">
                    
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Exam Date</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo $courses->otherdetails; ?></td>
                                    <td><?php echo e($courses->exam_Date); ?></td>
                                    <td><?php echo e($courses->exam_Date); ?></td>
                                    <td class="color-primary" style="text-align: center"><span class="fa fa-edit"></span> | <span class="fa fa-trash"></span></td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/courses/courseList.blade.php ENDPATH**/ ?>