<!-- resources/views/home.blade.php -->


<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'FAQ'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb text-right">
        <li><a href="<?php echo e(route('course.category')); ?>">Classes</a></li>
        <li><a href="<?php echo e(route('course.category')); ?>">FAQ</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default m-t-15">
                <div class="panel-heading">Add FAQ</div>
                <div class="panel-body">
                    <div class="card alert">
                        <div class="card-body">
                            <form action="<?php echo e(route('home.faqSave')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <p class="text-muted f-s-12">Title</p>
                                    <textarea id="editor" name="title"></textarea>
                                </div>

                                <div class="form-group">
                                    <p class="text-muted f-s-12">Details</p>
                                    <textarea id="editor1" name="details"></textarea>
                                </div>
                                <input type="submit" class="btn btn-warning btn-flat m-b-10 m-l-5" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <h4>Faq List</h4>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo $faqs->title; ?></td>
                                

                                <td style="text-align: center">
                                    <a href="<?php echo e(route('home.faqDelete', ['id' => $faqs->id])); ?>">
                                        <span class="fa fa-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('fileInput');
        const imagePreview = document.getElementById('imagePreview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                imagePreview.src = '#';
                imagePreview.style.display = 'none';
            }
        });
    </script>
    <script src="https://cdn.ckeditor.com/ckeditor5/33.0.0/classic/ckeditor.js"></script>

    <!-- Initialize CKEditor -->
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .then(editor => {
                console.log(editor);
            })
            .catch(error => {
                console.error(error);
            });

        ClassicEditor
            .create(document.querySelector('#editor1'))
            .then(editor1 => {
                console.log(editor1);
            })
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/Home/faq.blade.php ENDPATH**/ ?>