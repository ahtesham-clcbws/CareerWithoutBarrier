<!-- resources/views/home.blade.php -->


<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'Sub Category'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb text-right">
    <li><a href="<?php echo e(route('course.category')); ?>">Category</a></li>
    <li><a href="<?php echo e(route('course.subcategory')); ?>"> Sub Category</a></li>
    <li>Courses</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to our website!</h1>
    <!-- Your home page content goes here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/subcategory.blade.php ENDPATH**/ ?>