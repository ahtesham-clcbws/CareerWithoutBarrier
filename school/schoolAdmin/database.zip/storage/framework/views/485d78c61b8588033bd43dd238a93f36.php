<!-- resources/views/home.blade.php -->


<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startSection('pagetype', 'Slider'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb text-right">
        <li><a href="<?php echo e(route('course.category')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('course.category')); ?>">Slider</a></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default m-t-15">
                <div class="panel-heading">Add Slider</div>
                <div class="panel-body">
                    <div class="card alert">
                        <div class="card-body">
                            <form action="<?php echo e(route('home.saveSlider')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <p>Add Slider Image</p>
                                    <input type="file" id="fileInput" class="form-control input-focus" name="image">
                                    <img id="imagePreview" src="#" alt="Image Preview" style="display: none;width:200px">

                                </div>

                                <input type="submit" class="btn btn-warning btn-flat m-b-10 m-l-5" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <h4>Slider List</h4>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td> <img src="<?php echo e(asset('storage/' . $sliders->image)); ?>" style="width: 150px;border-radius:10px"></td>
                                <td>
                                    <span class="badge badge-<?php echo e($sliders->status ? 'primary' : 'dark'); ?>">
                                        <?php echo e($sliders->status ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>

                                <td style="text-align: center">
                                    <a href="<?php echo e(route('home.deleteSlider', ['id' => $sliders->id])); ?>">
                                        <span class="fa fa-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <script>
        const fileInput = document.getElementById('fileInput');
        const imagePreview = document.getElementById('imagePreview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                imagePreview.src = '#';
                imagePreview.style.display = 'none';
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeeva\school\schoolAdmin\resources\views/Admin/Home/slider.blade.php ENDPATH**/ ?>